﻿
using System.IO;
using System.Linq;
using System.Text;

using PublicSuffix.Rules;
using System.Net;
using System;
using System.Collections.Generic;

namespace PublicSuffix
{
    public class RulesListA : List<Rule>
    {
        public RulesListA() 
            : base()
        { 

        }

        /// <summary>
        /// IsValidRule, returns true when a rule string is valid.
        /// </summary>
        /// <param name="strRule">A rule string.</param>
        /// <returns><c>true</c> when the rule string is valid.</returns>
        private static bool IsValidRule(string strRule)
        {
            return !string.IsNullOrEmpty(strRule) && !strRule.StartsWith("//");
        }

        /// <summary>
        /// Updates the rule list from the original source.
        /// <param name="fileName">The file name that will be updated</param>
        /// </summary>
        public static void Update(string fileName)
        {
            UriBuilder tmpUriBuilder = new UriBuilder(RuleListFullPath);

            tmpUriBuilder.Query = "raw=1";

            using (WebClient client = new WebClient())
            using (Stream rawDataStream = client.OpenRead(tmpUriBuilder.Uri))
            using (TextReader rawDataReader = new StreamReader(rawDataStream))
                File.WriteAllText(fileName, rawDataReader.ReadToEnd());
        }

        /// <summary>
        /// Reads a PublixSuffix formatted file.
        /// </summary>
        /// <param name="file">The a text file.</param>
        /// <param name="update">Should the file be updated using latest. (default's to false)</param>
        /// <returns>An array of <see cref="Rule" />s.</returns>
        Rule[] FromFile(string file)
        {
            var lines = (from line in File.ReadAllLines(file, Encoding.UTF8)
                         where IsValidRule(line)
                         select RuleFactory.Get(line)).ToArray();

            this.AddRange(lines);

            return this.ToArray();
        }

        /// <summary>
        /// The web location where the rules list may be found.
        /// <remarks>We may decide to change where and how this is stored</remarks>
        /// </summary>
        const string RuleListFullPath = "http://mxr.mozilla.org/mozilla-central/source/netwerk/dns/effective_tld_names.dat";
    }

    /// <summary>
    /// From: http://publicsuffix.org/format/
    /// - The Public Suffix List consists of a series of lines, separated by \n.
    /// - Each line is only read up to the first whitespace; entire lines can also be commented using //.
    /// - Each line which is not entirely whitespace or begins with a comment contains a rule.
    /// See http://mxr.mozilla.org/mozilla-central/source/netwerk/dns/effective_tld_names.dat?raw=1 for the latest file.
    /// </summary>
    public static class RulesList
    {
        /// <summary>
        /// Reads a PublixSuffix formatted file.
        /// </summary>
        /// <param name="file">The a text file.</param>
        /// <param name="update">Should the file be updated using latest. (default's to false)</param>
        /// <returns>An array of <see cref="Rule" />s.</returns>
        public static Rule[] FromFile(string file)
        {
            var lines = (from line in File.ReadAllLines(file, Encoding.UTF8)
                         where IsValidRule(line)
                         select RuleFactory.Get(line)).ToArray();

            return lines;
        }

        /// <summary>
        /// IsValidRule, returns true when a rule string is valid.
        /// </summary>
        /// <param name="strRule">A rule string.</param>
        /// <returns><c>true</c> when the rule string is valid.</returns>
        private static bool IsValidRule(string strRule)
        {
            return !string.IsNullOrEmpty(strRule) && !strRule.StartsWith("//");
        }

        /// <summary>
        /// Updates the rule list from the original source.
        /// <param name="fileName">The file name that will be updated</param>
        /// </summary>
        public static void Update(string fileName)
        {
            UriBuilder tmpUriBuilder = new UriBuilder(RuleListFullPath);

            tmpUriBuilder.Query = "raw=1";

            using (WebClient client = new WebClient())
            using (Stream rawDataStream = client.OpenRead(tmpUriBuilder.Uri))
            using (TextReader rawDataReader = new StreamReader(rawDataStream))
                File.WriteAllText(fileName, rawDataReader.ReadToEnd());
        }

        /// <summary>
        /// The web location where the rules list may be found.
        /// <remarks>We may decide to change where and how this is stored</remarks>
        /// </summary>
        const string RuleListFullPath = "http://mxr.mozilla.org/mozilla-central/source/netwerk/dns/effective_tld_names.dat";
    }
}
